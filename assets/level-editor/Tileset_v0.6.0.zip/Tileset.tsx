<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tileset" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="Tileset.png" width="512" height="512"/>
 <tile id="33">
  <properties>
   <property name="data" value=""/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="data" value=""/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="data" value=""/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="data" value=""/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="data" value=""/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="data" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="data" type="int" value="0"/>
  </properties>
 </tile>
</tileset>
